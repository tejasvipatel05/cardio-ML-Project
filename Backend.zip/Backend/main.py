import joblib
import numpy as np
from flask import Flask, jsonify, request
from flask_cors import CORS  # CORS for frontend access

# Initialize Flask app
app = Flask(__name__)

# Enable CORS to allow requests from frontend
CORS(app)

# Load the trained model and scaler
model = joblib.load("cardio_model.pkl")  # Make sure this path is correct
scaler = joblib.load("scaler.pkl")  # Make sure this path is correct

# Model information (this can also be dynamic)
model_name = "Logistic Regression"  # Replace with the actual model name if dynamic
model_accuracy = 0.87  # Update with the actual accuracy from your model

# Define the input data format
class InputData:
    def __init__(self, age, gender, ap_hi, ap_lo, cholesterol, gluc, smoke, alco, active, height, weight):
        self.age = age
        self.gender = gender
        self.ap_hi = ap_hi
        self.ap_lo = ap_lo
        self.cholesterol = cholesterol
        self.gluc = gluc
        self.smoke = smoke
        self.alco = alco
        self.active = active
        self.height = height  # Height in cm
        self.weight = weight  # Weight in kg

# Function to calculate BMI
def calculate_bmi(height, weight):
    # Convert height from cm to meters
    height_in_meters = height / 100
    bmi = weight / (height_in_meters ** 2)
    return bmi

# Define the prediction endpoint
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from the POST request
        data = request.get_json()

        # Extract features from the request
        age = data['age']
        gender = data['gender']
        ap_hi = data['ap_hi']
        ap_lo = data['ap_lo']
        cholesterol = data['cholesterol']
        gluc = data['gluc']
        smoke = data['smoke']
        alco = data['alco']
        active = data['active']
        height = data['height']
        weight = data['weight']

        # Calculate BMI
        bmi = calculate_bmi(height, weight)

        # Prepare the input data for prediction (order of features must match model)
        input_data = np.array([[age, gender, ap_hi, ap_lo, cholesterol, gluc, smoke, alco, active, bmi]])

        # Scale the input data
        input_scaled = scaler.transform(input_data)

        # Make prediction using the model
        prediction = model.predict_proba(input_scaled)  # Get probabilities (high risk vs low risk)
        risk = prediction[0][1]  # Assuming second column is the "high risk" probability

        # Classify risk category based on the prediction
        if risk >= 0.7:
            risk_category = "High Risk"
        elif risk >= 0.3:
            risk_category = "Moderate Risk"
        else:
            risk_category = "Low Risk"

        # Prepare the response
        response = {
            "model_name": model_name,  # You can dynamically set this from your model if needed
            "accuracy": model_accuracy,  # Update with actual model accuracy
            "risk_class": risk_category,
            "risk_probability": risk
        }

        return jsonify(response)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Route to check if the API is working
@app.route('/')
def home():
    return "Cardiovascular Risk API is working!"

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
